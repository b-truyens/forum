<?php

namespace League\Glide\Signatures;

use Exception;

class SignatureException extends Exception
{
}
