---
layout: default
title: CakePHP integration
---

# CakePHP integration

Since CakePHP supports PSR-7 (since v3.6) and uses Zend Diactoros, you can follow the example shown for [PSR-7](/2.0/config/integrations/psr-7/) integration.

If you want a more advanced integration which included a middleware checkout the [ADmad/cakephp-glide](https://github.com/ADmad/cakephp-glide) plugin.
