## Reporting a Vulnerability

To report a security vulnerability, please use the [Algolia security email](security@algolia.com). Algolia will coordinate the fix and disclosure.
