<?php

namespace Algolia\AlgoliaSearch\Exceptions;

final class CannotWaitException extends AlgoliaException
{
}
