<?php

namespace Algolia\AlgoliaSearch\Exceptions;

class BadRequestException extends RequestException
{
}
