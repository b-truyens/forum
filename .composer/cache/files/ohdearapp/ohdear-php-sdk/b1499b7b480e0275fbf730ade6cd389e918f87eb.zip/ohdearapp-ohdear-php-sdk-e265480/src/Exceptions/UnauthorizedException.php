<?php

namespace OhDear\PhpSdk\Exceptions;

use Exception;

class UnauthorizedException extends Exception
{
}
