<?php

namespace OhDear\PhpSdk\Resources;

class Team extends ApiResource
{
    public int $id;

    public string $name;
}
