<?php

namespace OhDear\PhpSdk\Resources;

class Uptime extends ApiResource
{
    public string $datetime;

    public float $uptimePercentage;
}
