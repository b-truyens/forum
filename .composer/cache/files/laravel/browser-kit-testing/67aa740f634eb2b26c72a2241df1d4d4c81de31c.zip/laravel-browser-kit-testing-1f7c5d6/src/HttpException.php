<?php

namespace Laravel\BrowserKitTesting;

use PHPUnit\Framework\AssertionFailedError;

class HttpException extends AssertionFailedError
{
    //
}
