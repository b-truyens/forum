<img src="{{ $url() }}" {{ $attributes }}/>
