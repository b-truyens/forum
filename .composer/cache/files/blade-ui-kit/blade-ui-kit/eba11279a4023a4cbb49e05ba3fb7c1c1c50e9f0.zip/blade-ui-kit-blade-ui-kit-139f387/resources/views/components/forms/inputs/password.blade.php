<input
    name="{{ $name }}"
    type="password"
    id="{{ $id }}"
    {{ $attributes }}
/>
