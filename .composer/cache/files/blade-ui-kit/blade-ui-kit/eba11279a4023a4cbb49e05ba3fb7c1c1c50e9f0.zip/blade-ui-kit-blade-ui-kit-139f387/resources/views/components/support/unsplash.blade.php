<img src="{!! $url !!}" {{ $attributes }}/>
