<label for="{{ $for }}" {{ $attributes }}>
    {{ $fallback }}
</label>
