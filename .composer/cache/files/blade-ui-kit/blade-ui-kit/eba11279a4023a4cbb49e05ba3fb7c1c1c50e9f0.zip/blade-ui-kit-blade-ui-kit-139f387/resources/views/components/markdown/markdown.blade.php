<div {{ $attributes }}>
    {!! $toHtml($slot) !!}
</div>
