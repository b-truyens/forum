<?php

namespace Illuminate\Routing
{
    class Router
    {
        public function feeds(): void {}
    }
}

namespace Illuminate\Support\Facades
{
    class Route
    {
        public static function feeds(): void {}
    }
}
