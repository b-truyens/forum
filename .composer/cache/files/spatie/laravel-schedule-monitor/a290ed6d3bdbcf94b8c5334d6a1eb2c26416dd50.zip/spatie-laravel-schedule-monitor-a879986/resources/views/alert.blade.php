<div class="mt-1 mx-2 {{ $class ?? '' }}">
    {!! $message !!}
</div>
