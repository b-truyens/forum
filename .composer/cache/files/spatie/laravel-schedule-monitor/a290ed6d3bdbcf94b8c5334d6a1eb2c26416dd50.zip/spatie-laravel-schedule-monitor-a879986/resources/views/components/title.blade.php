<div class="bg-blue-600 text-white font-bold px-1">
    {{ $slot }}
</div>
