<?php

namespace Spatie\ScheduleMonitor\Exceptions;

use Exception;

class InvalidClassException extends Exception
{
}
