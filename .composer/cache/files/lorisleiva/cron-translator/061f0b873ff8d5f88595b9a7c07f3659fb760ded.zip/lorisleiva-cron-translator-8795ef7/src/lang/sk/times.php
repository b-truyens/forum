<?php

return [
    'default' => ':number-krát',
    1 => 'raz',
    2 => 'dva razy',
];
