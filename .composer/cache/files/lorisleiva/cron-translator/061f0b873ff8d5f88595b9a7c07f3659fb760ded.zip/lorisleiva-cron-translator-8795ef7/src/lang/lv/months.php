<?php

return [
    1 => 'janvārī',
    2 => 'februārī',
    3 => 'martā',
    4 => 'aprīlī',
    5 => 'maijā',
    6 => 'jūnijā',
    7 => 'jūlijā',
    8 => 'augustā',
    9 => 'septembrī',
    10 => 'oktobrī',
    11 => 'novembrī',
    12 => 'decembrī',
];
