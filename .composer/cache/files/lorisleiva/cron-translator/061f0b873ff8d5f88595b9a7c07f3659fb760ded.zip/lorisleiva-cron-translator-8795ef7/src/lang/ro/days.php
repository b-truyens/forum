<?php

return [
    1 => 'Luni',
    2 => 'Marți',
    3 => 'Miercuri',
    4 => 'Joi',
    5 => 'Vineri',
    6 => 'Sâmbătă',
    7 => 'Duminică',
];
