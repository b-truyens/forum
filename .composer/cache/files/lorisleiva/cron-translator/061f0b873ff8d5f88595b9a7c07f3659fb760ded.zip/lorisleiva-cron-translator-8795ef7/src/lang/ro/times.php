<?php

return [
    'default' => 'de :number ori',
    1 => 'o singură dată',
];
