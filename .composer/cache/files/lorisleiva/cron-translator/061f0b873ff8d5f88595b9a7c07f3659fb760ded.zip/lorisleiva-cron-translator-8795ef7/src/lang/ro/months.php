<?php

return [
    1 => 'Ianuarie',
    2 => 'Februarie',
    3 => 'Martie',
    4 => 'Aprilie',
    5 => 'Mai',
    6 => 'Junie',
    7 => 'Julie',
    8 => 'August',
    9 => 'Septembrie',
    10 => 'Octobrie',
    11 => 'Noiembrie',
    12 => 'Decembrie',
];
