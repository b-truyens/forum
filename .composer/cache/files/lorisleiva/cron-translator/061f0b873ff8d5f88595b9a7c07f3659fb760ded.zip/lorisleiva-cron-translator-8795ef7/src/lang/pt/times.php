<?php

return [
    'default' => ':number vezes',
    1 => 'uma vez',
];
