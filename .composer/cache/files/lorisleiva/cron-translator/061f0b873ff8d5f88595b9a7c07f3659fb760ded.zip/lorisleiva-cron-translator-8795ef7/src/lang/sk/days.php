<?php

return [
    1 => 'pondelok',
    2 => 'utorok',
    3 => 'streda',
    4 => 'štvrtok',
    5 => 'piatok',
    6 => 'sobota',
    7 => 'nedeľa',
];
