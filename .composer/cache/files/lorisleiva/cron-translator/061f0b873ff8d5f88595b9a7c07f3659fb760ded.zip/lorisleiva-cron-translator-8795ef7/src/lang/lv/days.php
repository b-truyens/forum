<?php

return [
    1 => 'pirmdien',
    2 => 'otrdien',
    3 => 'trešdien',
    4 => 'ceturtdien',
    5 => 'piektdien',
    6 => 'sestdien',
    7 => 'svētdien',
];
