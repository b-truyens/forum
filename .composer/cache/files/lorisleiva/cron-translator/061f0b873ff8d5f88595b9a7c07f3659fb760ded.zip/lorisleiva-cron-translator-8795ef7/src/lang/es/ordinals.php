<?php

return [
    'default' => ':numberº',
];
