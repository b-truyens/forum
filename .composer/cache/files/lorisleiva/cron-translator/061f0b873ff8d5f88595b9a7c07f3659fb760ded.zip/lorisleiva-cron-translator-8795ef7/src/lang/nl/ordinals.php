<?php

return [
    'default' => ':numbere',
];
