<?php

return [
    1 => 'Tháng Một',
    2 => 'Tháng Hai',
    3 => 'Tháng Ba',
    4 => 'Tháng Tư',
    5 => 'Tháng Năm',
    6 => 'Tháng Sáu',
    7 => 'Tháng Bảy',
    8 => 'Tháng Tám',
    9 => 'Tháng Chín',
    10 => 'Tháng Mười',
    11 => 'Tháng Mười Một',
    12 => 'Tháng Mười Hai',
];
