<?php

return [
    'default' => ':number lần'
];
