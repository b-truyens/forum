<?php

return [
    'default' => ':number',
];
