<?php

return [
    'default' => ':number keer',
];
