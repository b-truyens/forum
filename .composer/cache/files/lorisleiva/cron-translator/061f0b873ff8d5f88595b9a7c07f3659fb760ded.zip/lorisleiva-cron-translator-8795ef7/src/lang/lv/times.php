<?php

return [
    'default' => ':number reizes',
    1 => 'vienreiz',
    2 => 'divreiz',
];
