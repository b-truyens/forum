<?php

return [
    'default' => ':number times',
    1 => 'once',
    2 => 'twice',
];
