<?php

return [
    'default' => ':number.',
    #'default' => str_pad(':number', 2, 0, STR_PAD_LEFT). '.',
    1 => '1.',
    2 => '2.',
    3 => '3.',
    21 => '21.',
    22 => '22.',
    23 => '23.',
    31 => '31.',
];
