<?php

return [
    'default' => ':number次',
];
