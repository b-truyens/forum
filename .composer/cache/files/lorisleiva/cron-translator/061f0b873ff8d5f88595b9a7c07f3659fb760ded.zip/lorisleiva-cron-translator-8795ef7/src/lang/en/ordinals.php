<?php

return [
    'default' => ':numberth',
    1 => '1st',
    2 => '2nd',
    3 => '3rd',
    21 => '21st',
    22 => '22nd',
    23 => '23rd',
    31 => '31st',
];
