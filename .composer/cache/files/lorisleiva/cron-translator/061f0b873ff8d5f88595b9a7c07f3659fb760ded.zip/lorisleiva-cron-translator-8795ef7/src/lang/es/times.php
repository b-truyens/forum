<?php

return [
    'default' => ':number veces',
    1 => 'una vez',
];
