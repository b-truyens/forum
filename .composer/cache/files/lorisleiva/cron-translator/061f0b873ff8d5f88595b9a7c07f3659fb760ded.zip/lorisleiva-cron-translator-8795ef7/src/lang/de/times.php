<?php

return [
    'default' => ':number',
    1 => 'Ein',
    2 => 'Zwei',
];
