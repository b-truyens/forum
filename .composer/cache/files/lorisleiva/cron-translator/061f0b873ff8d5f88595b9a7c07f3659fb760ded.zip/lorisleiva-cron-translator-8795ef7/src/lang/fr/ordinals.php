<?php

return [
    'default' => ':number',
    1 => '1er',
];
