<?php

return [
    'default' => ':number बार',
    1 => 'एक बार',
    2 => 'दो बार',
];
