<?php

return [
    'default' => ':number أوقات',
    1 => 'مرة',
    2 => 'مرتان',
];
