<?php

return [
    'default' => 'ngày :number'
];
