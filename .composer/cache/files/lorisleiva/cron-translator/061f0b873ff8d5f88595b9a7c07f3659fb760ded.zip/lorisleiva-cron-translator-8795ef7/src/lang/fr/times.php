<?php

return [
    'default' => ':number fois',
    1 => 'une fois',
    2 => 'deux fois',
];
