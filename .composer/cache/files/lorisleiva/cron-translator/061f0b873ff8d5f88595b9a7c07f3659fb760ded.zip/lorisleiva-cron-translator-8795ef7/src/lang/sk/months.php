<?php

return [
    1 => 'január',
    2 => 'február',
    3 => 'marec',
    4 => 'apríl',
    5 => 'máj',
    6 => 'jún',
    7 => 'júl',
    8 => 'august',
    9 => 'september',
    10 => 'október',
    11 => 'november',
    12 => 'december',
];
