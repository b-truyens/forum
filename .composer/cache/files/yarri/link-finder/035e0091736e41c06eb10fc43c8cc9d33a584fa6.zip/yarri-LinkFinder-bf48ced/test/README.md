Unit Testing for LinkFinder
---------------------------

In this directory just run:

    ../vendor/bin/run_unit_tests
