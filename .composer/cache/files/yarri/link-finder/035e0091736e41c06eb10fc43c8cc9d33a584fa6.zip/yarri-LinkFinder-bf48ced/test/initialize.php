<?php
define("TEST",true);
require(__DIR__ . "/../vendor/autoload.php");
